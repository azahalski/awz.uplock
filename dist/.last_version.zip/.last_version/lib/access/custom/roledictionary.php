<?php
namespace Awz\Uplock\Access\Custom;

use Awz\Uplock\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}