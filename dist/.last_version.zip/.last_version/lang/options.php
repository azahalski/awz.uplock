<?php
$MESS['AWZ_UPLOCK_OPT_TITLE'] = "AWZ: Блокировка обновлений";
$MESS['AWZ_UPLOCK_OPT_L_BTN_SAVE'] = "Сохранить настройки";
$MESS['AWZ_UPLOCK_OPT_SECT1'] = "Настройки блокировок";
$MESS['AWZ_UPLOCK_OPT_SECT2'] = "Права доступа";
$MESS['AWZ_UPLOCK_OPT_VERSION'] = "Версия";
$MESS['AWZ_UPLOCK_OPT_LOCK'] = "Запретить обновление";
$MESS['AWZ_UPLOCK_OPT_LOCK_MSG'] = "Текст ошибки";
$MESS['AWZ_UPLOCK_OPT_MODULE'] = "Код модуля";
$MESS['AWZ_UPLOCK_OPT_MODULE_DSBL'] = "Отключить модуль";
$MESS['AWZ_UPLOCK_OPT_MODULE_INSTALL'] = "Запретить установку модулей";
