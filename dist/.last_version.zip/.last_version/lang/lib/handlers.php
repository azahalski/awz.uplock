<?php
$MESS["AWZ_UPLOCK_HANDLERS_MSG_NOTALL"] = 'Отметьте модули на вкладке список обновлений и нажмите кнопку загрузить.';
$MESS["AWZ_UPLOCK_HANDLERS_MSG"] = 'Обновление #MODULE_ID# заблокировано модулем <a href="/bitrix/admin/settings.php?mid=awz.uplock&lang=ru&mid_menu=1">awz.uplock</a>.';
$MESS["AWZ_UPLOCK_HANDLERS_LOCK_ADD"] = "Установка данного модуля запрещена администратором.";