<?
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2025-07-15 02:03:00"
);
?>