drop table if exists awz_uplock_role;
drop table if exists awz_uplock_role_relation;
drop table if exists awz_uplock_permission;